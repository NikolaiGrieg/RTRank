--- todo?

RTRank:initEvents()