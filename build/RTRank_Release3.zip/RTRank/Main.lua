--- todo?

RTRank:initEvents()